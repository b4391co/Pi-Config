# Guía de contribución

La siguiente guía presentará la forma de contribución a este material de forma ordenada y pautada. Trabajar sin atender a un conjunto mínimo de normas hace que el trabajo colaborativo sea imposible, por este motivo sigue rigurosamente las indicaciones de este documento para que tu trabajo pueda ser *mergeado*.

- [1. Sobre la sintaxis](#1-sobre-la-sintaxis)
- [2. Sobre ramas](#2-sobre-ramas)
- [3. Sobre *merge request* e *issues*](#3-sobre-merge-request-e-issues)
- [4. Sobre imágenes](#4-sobre-imágenes)
- [5. Sobre estructura del contenido](#5-sobre-estructura-del-contenido)

## 1. Sobre la sintaxis

La sintaxis utilizada será la de [markdown](https://es.wikipedia.org/wiki/Markdown). Es muy importante de que cumplas todas las reglas de markdown y pases la herramienta lint.

## 2. Sobre ramas

Separa utilizando ramas. Para todas tus contribuciones y los merge request que harás a continuación debes crear ramas independientes.

Situación de ejemplo; Estás realizando un recurso en markdown para una actividad práctica o píldora formativa, investigación, etc. En ese momento descubres una errata en otro documento. Lo que deberías hacer entonces es commitear todos tus cambios en la rama de trabajo actual, luego cambiar a la rama `main` (actualizada), y crear una rama específica para la errata. De esta forma tendrás separadas tus dos contribuciones.

## 3. Sobre *merge request* e *issues*

Cuando asumas una tarea en este recurso, crea una issue (si no existe ya) en el repo origen (el del grupo). En ella describe tu trabajo y si hay que hacer algún comentario al respecto, en la issue se comentará.

Toda la integración de tu trabajo con la rama de publicación (`main`) se hará a través de un merge request.

## 4. Sobre imágenes

- Siempre deben ir ubicadas en la carpeta `img` que se encuentre en el mismo directorio que el recurso markdown que utilice la imagen. Si hay dos recursos que utilicen la misma imagen pero que están en paths diferentes, entonces duplica la imagen.
- Las imágenes como máximo deben tener una anchura de 600px. Si no fuese así, realiza una redimensión de la misma.
- Asegúrate que tus imágenes pesen poco.
- Puedes incluir gifs animados, pero asegúrate de que sea razonable su peso. Optimiza mucho la frecuencia de imagen y la duración del propio gif.

## 5. Sobre estructura del contenido

- La estructura del contenido vendrá generalmente dada. Cada '*píldora formativa*' será un directorio que contenga un fichero `_index.md` que describirá ese recurso.
