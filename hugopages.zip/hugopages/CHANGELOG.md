# Changelog

Todos los cambios notables en este proyecto deberán ser documentados en este fichero.

El formato está basado en [*Keep a Changelog*](https://keepachangelog.com/en/1.0.0/),
y este proyecto se adiere a [*Semantic Versioning*](https://semver.org/spec/v2.0.0.html).

Puedes y debes alterar este fichero conforme vayas generando versiones:

## [Unreleased]

[ ] Bash Script by Breogán Lodeiro
[ ] Fundamentos de Arquitectura ARM by Aldo de Tena y Miguel de Tena
[ ] Lenguaje de programación Java (fundamentos) by Gonzalo Feijóo
[ ] Lenguaje de programación C# (fundamentos) by Eduardo de Nóvoa y Javier Sanisidro
[ ] Lenguaje de programación PHP (fundamentos) by Antonio Sodoval
[ ] Lenguaje de programación Kotlin (fundamentos) by Valentín Pazos
[ ] Lenguaje de programación Swift (fundamentos) by Jorge Rey
[ ] Lenguaje de programación C++ (fundamentos) by Eduardo de Nóvoa
[ ] Lenguaje de programación Go (fundamentos) by Martín Cambón
[ ] Lenguajes de marcado y especificacion XML, JSON, YAML by Juan Manuel Tomás
[ ] Herramienta de Maven como herramienta gestora del Proceso Sotware by Gonzalo Feijóo
[ ] Demostración sobre el uso del framework '*react native*' by David Mareque
[ ] Demostración del uso de un IDE de desarrollo y de Python en el contexto de la Big Data e IA
[ ] Demostración de cómo desarrollar una API en Python y *pip* como gestor del Proceso by David Barros
[ ] Demostración de cómo desarrollar con el framework *React* y 'yarn' como gestor del Proceso by David Barros

## [`v0.7.0`] - 2022-01-18

- Lenguaje de programación Ruby by Aaron Rodríguez
- Artículo sobre NodeJS® by Kevin López
- Agile y Scrum
- El Proceso Software
- Recetas sobre git
- Planteados artículos (TODO) sobre Procedimientos y técnicas en programación

## [`v0.2.1`] - 2022-12-24

Updated submodule 'hugo-theme-relearn'. Apuntamos a `v5.9.1`

Troubleshooting:

Justo en el commit `54df05b91d51a4e329f3c00614a7c4b1d56dcc29` (`theme: modularize render image hook #373`) donde estaba apuntando `main` cuando me cloné el repo, tenía un bug (o eso parece) porque hicieron un cambio relativo a las imágenes (v5.4.3)

v5.5.0: smile FUNCIONA!
54df05b91d51a4e329f3c00614a7c4b1d56dcc29: (main) angry no funciona
v5.4.3: angry No funciona
v5.4.2: smile FUNCIONA!

## [`v0.2.0`] - 2022-12-24

- Sobre firma en git
- Fundamentos Javascript
- Creada estructura básica del proyecto Estructura, pipeline, guía de contribución
