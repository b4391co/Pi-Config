# Materiales del Curso de Especialización en Ciberseguridad (PPS)

**El propósito de estos materiales es el de compartir y generar documentación, material de consulta y la trasladar la documentación facilitada en el módulo del ciclo de Ciberseguridad**, concretamente sobre *Puesta en producción segura* (PPS).

La elaboración de la documentación accesible en este repo será generada en parte por la aportación de los docentes del ciclo de formación pero también se realizará en el marco de las actividades prácticas realizadas durante el curso. Se establecerán objetivos para que los alumnos participen realizando una investigación propuesta por el docente, generando como se mencionaba, un material de forma colaborativa. La temática será variaba y dirigida por las competencias que se deben adquirir en el curso de especialización.

La forma de contribuir como de los mecanismos, estrategias y herramientaas, estarán descritos en su correspondiente apartado. Así mismo, la documentación estará bajo licencia de documentación libre (GNU) y se prestará especial reconocimiento a los autores que han aportado su trabajo. La función de integrar el trabajo para su publicación recae inicialmente sobre los docentes, puediendo evolucionar esto hacia un modelo de autogestión. En primera instancia, la responsabilidad sobre qué se publica o no recaerá inicialmente sobre los docentes.

**La documentación generada será escrita en markdown valiéndose de herramientas de generación estática de *websites*** como lo es [*Hugo Pages*](https://gohugo.io/about/).

## Installation

No es estrictamente necesario instalar ningún software adicional para poder contribuir, aunque sin embargo sería muy interesante poder visualizar corectamente el *website* de forma local.

Para ello podemos [instalar la herramienta *Hugo*](https://gohugo.io/installation/) que nos facilitará la posibilidad de realizar un *renderizado* de los documentos markdown a código HTML, sus estilos (en base a una *template*) y su utilidades (búsqueda, indexado, etc...).

La forma de instalación recomendada en un ambiente Linux/MacOS es:

```bash
brew install hugo
```

También existe la forma sin necesidad de instalación de ningún binario utilizando docker, concretamente [la imagen de hugo en docker](https://hub.docker.com/r/klakegg/hugo):

```bash
docker pull klakegg/hugo
```

## Uso

Primero clona el repo y después inicializa los submódulos de la siguiente manera.

```bash
# Registramos los módulos (interpreta .gitmodules)
git submodule init

# Para recupear el contenido del submodulo
git submodule update
```

Posteriormente dependiendo de una instalación '*On premise*' o no:

```bash
# Ejecución del webserver con instalación On premise
hugo server -D
```

Con docker:

```bash
# Sitúate en la raiz del repo para iniciar correctamente el webserver
docker run --rm -it \
            -v $(pwd):/src \
            -p 1313:1313 \
            klakegg/hugo:0.101.0 \
            server
```

## Contribuyendo

**Lee atentamente [las reglas o normas para contribuir](./CONTRIBUTING.md) en los contenidos.**

Los *Pull Request* o *Merge Request* son bienvenidos. Para cambios mayores, por favor abre una *issue* comprobando que no existe una *issue* similar que ya ha sido asignada. Si existe la *issue* y no está asignada te la puedes autoasignar. Si no existe la puedes crear. En las *issues* se discutirá qué te gustaría cambiar.

## Licencia

[GNU Free Documentation License](https://www.gnu.org/licenses/fdl-1.3.html)
